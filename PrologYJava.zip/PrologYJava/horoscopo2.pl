
horoscopo3(piscis,"No permitas que habladur�as y chismes te
arruinen el d�a,recuerda que si hablan de ti
es porque les molesta lo que proyectas y eres.").
horoscopo3(acuario,"En el trabajo vienen cosas
positivas sin embargo si estas en
espera de mejores ingresos recuerda
que quien no habla con Dios no lo oye,
es momento de buscar mejores oportunidades").
horoscopo3(capricornio,"Tienes ciertos
problemas con tu pasado que te detienen
y te hacen dudar hasta de tu nombre,
    no seas tan desconfiado y vive tu vida").
horoscopo3(sagitario,"Se alejara de ti
una persona muy importante que te mov�a,
no detengas a ese ser o solo te
expondr�s a que si se queda haga de ti lo que le de su gana").
horoscopo3(escorpio,"Un ex pareja te ha recordado mucho
son embargo teme acercarse
a ti, el karma le ha dado buenas lecciones").
horoscopo3(libra,"No temas a cambios en tu vida pues te
llevar�n a mejorar eb muchos aspectoss, recuerda
que nuevos cambios traer�n consigo nuevas oportunidades").
horoscopo3(virgo,"Vienen cambios importantes
en tu vida entre ellos la oportunidad de dejar ir todo
y deshacerte de todo eso que te ha impedido seguir avanzando").
horoscopo3(leo,"Es momento que dejes de ser tan d�bil
y pienses m�s en lo que puedes obtener, �chala muchas ganas
a proyectos pues sueles dejar muchas cosas inconclusas").
horoscopo3(cancer,"No caigas en provocaciones tontas
pues este fin de semana andar�s algo bipolar
y cambiante en tu car�cter, pero esi se debe a
ciertas situaciones que te tienen algo nervios@").
horoscopo3(geminis,"No eres mal@, pero cuando te
buscan te encuentran, el amor quiz�s no se ha hecho
para ti en estos momentos, pero una cosa es cierta,
    cuando dejes de buscarlo y obsesionarte con �l llegar� a tu vida").
horoscopo3(tauro,"Deja de pensar en tu pasado y ve por tu
presente que lo has descuidado mucho por quien no merece ni un segundo de tu atenci�n").
horoscopo3(aries,"No te atontes di lo que sientes y ve por lo
que necesitas, que te valgan comentarios tontos de gente
imbecil que solo busca lastimarte o hacerte da�o, sabes lo perr@ que puedes ser cuando te lo propones").

prueba2(X,Y):-horoscopo3(X,Y).
