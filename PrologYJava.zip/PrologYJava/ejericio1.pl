% la suma de 2 numeros
  suma(A,B,C) :-C is A+B.
 resta(A,B,C) :-C is A-B.
 divide(A,B,C) :-C is A/B.
multiplica(A,B,C) :-C is A*B.




