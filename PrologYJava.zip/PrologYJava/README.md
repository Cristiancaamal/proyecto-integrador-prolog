# JavaAndProlog
#This a project where you can find the way that you can make the connection with prolog and java.
Follow me on Instagram dulcebick96..
Be happy!!!
If you have any question, please send me an e-mail: bick_candy@hotmail.com
